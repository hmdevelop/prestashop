SET NAMES 'utf8';
